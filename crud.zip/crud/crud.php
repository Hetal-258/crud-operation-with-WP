<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://http://localhost/crudwp
 * @since             1.0.0
 * @package           Crud
 *
 * @wordpress-plugin
 * Plugin Name:       Crudoperation
 * Plugin URI:        https://http://localhost/crudwp
 * Description:       crud operation perform with insert,delete,update.
 * Version:           1.0.0
 * Author:            devteam
 * Author URI:        https://http://localhost/crudwp
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       crud
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'CRUD_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-crud-activator.php
 */
function activate_crud() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-crud-activator.php';
	Crud_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-crud-deactivator.php
 */
function deactivate_crud() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-crud-deactivator.php';
	Crud_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_crud' );
register_deactivation_hook( __FILE__, 'deactivate_crud' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-crud.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_crud() {

	$plugin = new Crud();
	$plugin->run();

}
run_crud();


register_activation_hook(__FILE__, 'table_creator');
function table_creator()
{
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();
    $table_name = $wpdb->prefix . 'ems';
    $sql = "DROP TABLE IF EXISTS $table_name;
            CREATE TABLE $table_name(
            id mediumint(11) NOT NULL AUTO_INCREMENT,
            emp_id varchar(50) NOT NULL,
            emp_name varchar (250) NOT NULL,
            emp_email varchar (250) NOT NULL,
            emp_dept varchar (250) NOT NULL,
            PRIMARY KEY id(id)
            )$charset_collate;";
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}

add_shortcode('frontend_crud','da_ems_frontend_crud_callback');

function da_ems_frontend_crud_callback(){

    global $wpdb;
    $table_name = $wpdb->prefix.'ems';
    $msg = '';
    if(@$_REQUEST['action'] == 'submit'){

        $wpdb->insert("$table_name", [
            'emp_id' => sanitize_text_field($_REQUEST['emp_id']),
            'emp_name'=> sanitize_text_field($_REQUEST['emp_name']),
            'emp_email'=> sanitize_email($_REQUEST['emp_email']),
            'emp_dept'=> sanitize_text_field($_REQUEST['emp_dept']),
        ]);

        if($wpdb->insert_id > 0){
            $msg = "Saved Successfully";
        }else{
            $msg = "Failed to save data";
        }


    }

    if(@$_REQUEST['action'] == 'update-emp' && @$_REQUEST['id']){

        $id = @$_REQUEST['id'];

        if(@$_REQUEST['emp_id'] && @$_REQUEST['emp_name'] && @$_REQUEST['emp_email'] && @$_REQUEST['emp_dept']){
            $update = $wpdb->update("$table_name",[
                'emp_id' =>sanitize_text_field($_REQUEST['emp_id']),
                'emp_name' =>sanitize_text_field($_REQUEST['emp_name']),
                'emp_email' =>sanitize_email($_REQUEST['emp_email']),
                'emp_dept' =>sanitize_text_field($_REQUEST['emp_dept'])],
                ['id' => $id]);

            if($update){
                $msg = "Data Updated <a href='".get_page_link(get_the_ID())."'>Add Employee</a>";
            }

        }

        $employee = $wpdb->get_row($wpdb->prepare("select * from $table_name where id = %d", $id), ARRAY_A);

        $emp_id = $employee['emp_id'];
        $emp_name = $employee['emp_name'];
        $emp_email = $employee['emp_email'];
        $emp_dept = $employee['emp_dept'];
    }

    if(@$_REQUEST['action'] == 'delete-emp' && @$_REQUEST['id']){

        $id = @$_REQUEST['id'];

        if($id){
            $row_exits = $wpdb->get_row($wpdb->prepare("select * from $table_name where id = %d",$id),ARRAY_A);

            if(count($row_exits)> 0){

                $wpdb->delete("$table_name", array('id'=>$id));
            }
        }
        ?>
            <script>
                location.href="<?php echo get_the_permalink(); ?>";
            </script>
        <?php
    }

    ?>

    <div class="form_container">

    <h4><?php echo @$msg; ?></h4>
    <form method="post">

        <p>
            <label>EMP ID</label>
            <input type="text" name="emp_id" value="<?php echo @$emp_id; ?>" placeholder="Enter ID" required>

        </p>

        <p>
            <label>Name</label>
            <input type="text" name="emp_name"  value="<?php echo @$emp_name; ?>" placeholder="Enter Name" required>

        </p>
        <p>
            <label>Email</label>
            <input type="email" name="emp_email" value="<?php echo @$emp_email; ?>" placeholder="Enter Email" required>
        </p>
        <p>
            <label>Department</label>
            <input type="text" name="emp_dept" value="<?php echo @$emp_dept; ?>" placeholder="Enter Department" required>
        </p>

        <p>
            <button type="submit" name="action" value="<?php echo (@$_REQUEST['action'] == 'update-emp')?'update-emp':'submit'; ?>"><?php echo (@$_REQUEST['action'] == 'update-emp')?'Update':'Submit'; ?></button>
        </p>
    </form>

    </div>
<?php

    $employee_list = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    $i = 1;
    if($employee_list > 0 ){ ?>

        <div style="margin-top: 40px">
            <table border="1" cellpadding="10" style="font-size:14px;">
                <tr>
                <th>S. No.</th>
                <th>EMP ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Dept.</th>
                <th>Action</th>
                </tr>
                <?php foreach ($employee_list as $index =>  $employee):

                    ?>
                    <tr>
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $employee['emp_id'];  ?></td>
                        <td><?php echo $employee['emp_name']; ?></td>
                        <td><?php echo $employee['emp_email'];; ?></td>
                        <td><?php echo $employee['emp_dept'];; ?></td>
                        <td>
                            <a href="?action=update-emp&id=<?php echo $employee['id']; ?>">Update</a>
                            <a href="?action=delete-emp&id=<?php echo $employee['id']; ?>" onclick="return confirm('Are you sure to remove this record?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>


        </div>



    <?php }
}